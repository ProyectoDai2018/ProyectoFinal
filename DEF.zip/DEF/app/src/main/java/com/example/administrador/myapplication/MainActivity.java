package com.example.administrador.myapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;


/*Creado por:
* Jerusa Chavero,
 * Andrés Aguilar,
  * Karina Torres,
  * Edgar Lozano */
public class MainActivity extends AppCompatActivity {

    private CheckBox carne;
    private CheckBox pollo;
    private CheckBox pescado;
    private CheckBox quesoPanela;
    private CheckBox falafel;

    private CheckBox lechuga;
    private CheckBox jicama;
    private CheckBox pepino;
    private CheckBox pimiento;
    private CheckBox espinaca;

    private CheckBox ad1;
    private CheckBox ad2;
    private CheckBox ad3;
    private CheckBox ad4;
    private CheckBox ad5;

    private CheckBox croutons;
    private CheckBox panArabe;
    private CheckBox pasta;
    private CheckBox pure;

    private CheckBox barraAma;
    private CheckBox coctel;
    private CheckBox mix;
    private CheckBox eBar;

    private EditText fecha;


    /*
    * Este método crea la primera ventana.
    * Aquí se instancian los checkBox y el editText de xml para que puedan ser utilizados
    * También instancia los datos en la base de datos "info" para ser usados después */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        carne = (CheckBox) findViewById(R.id.cbCarne);
        pollo = (CheckBox) findViewById(R.id.cbPollo);
        pescado = (CheckBox) findViewById(R.id.cbPescado);
        quesoPanela = (CheckBox) findViewById(R.id.cbQuesoPanela);
        falafel = (CheckBox) findViewById(R.id.cbFalafel);

        lechuga = (CheckBox) findViewById(R.id.cbLechuga);
        jicama = (CheckBox) findViewById(R.id.cbJicama);
        pepino = (CheckBox) findViewById(R.id.cbPepino);
        pimiento = (CheckBox) findViewById(R.id.cbPimiento);
        espinaca = (CheckBox) findViewById(R.id.cbEspinaca);

        ad1 = (CheckBox) findViewById(R.id.cbA1);
        ad2 = (CheckBox) findViewById(R.id.cbA2);
        ad3 = (CheckBox) findViewById(R.id.cbA3);
        ad4 = (CheckBox) findViewById(R.id.cbA4);
        ad5 = (CheckBox) findViewById(R.id.cbA5);

        croutons = (CheckBox) findViewById(R.id.cbCroutons);
        panArabe = (CheckBox) findViewById(R.id.cbPanArabe);
        pasta = (CheckBox) findViewById(R.id.cbPasta);
        pure = (CheckBox) findViewById(R.id.cbPure);

        barraAma = (CheckBox) findViewById(R.id.cbSn1);
        coctel = (CheckBox) findViewById(R.id.cbSn2);
        mix = (CheckBox) findViewById(R.id.cbSn3);
        eBar = (CheckBox) findViewById(R.id.cbSn4);

        fecha=(EditText) findViewById(R.id.etFecha);

        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        ContentValues registro=new ContentValues();


        registro.put("idI", 1001);
        registro.put("proteina", "20,72g");
        registro.put("carb", "0g");
        registro.put("cal", "146kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "6,43g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1002);
        registro.put("proteina", "23,33g");
        registro.put("carb", "0g");
        registro.put("cal", "144kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "4,9g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1003);
        registro.put("proteina", "24,68g");
        registro.put("carb", "0g");
        registro.put("cal", "219kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "12,56g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1004);
        registro.put("proteina", "18,09g");
        registro.put("carb", "2,98g");
        registro.put("cal", "299kcal");
        registro.put("azucares","2,32g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "23,82g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1005);
        registro.put("proteina", "20,47g");
        registro.put("carb", "62,95g");
        registro.put("cal", "378kcal");
        registro.put("azucares","10,7g" );
        registro.put("fibras","12,2g" );
        registro.put("grasas", "6,04g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1006);
        registro.put("proteina", "0g");
        registro.put("carb", "1,03g");
        registro.put("cal", "5kcal");
        registro.put("azucares","0,28g" );
        registro.put("fibras","0,5g" );
        registro.put("grasas", "0,05g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1007);
        registro.put("proteina", "0g");
        registro.put("carb", "2,03g");
        registro.put("cal", "10kcal");
        registro.put("azucares","2,0g" );
        registro.put("fibras","5g" );
        registro.put("grasas", "1,2g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1008);
        registro.put("proteina", "0g");
        registro.put("carb", "0g");
        registro.put("cal", "146kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "6,43g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1009);
        registro.put("proteina", "0,34g");
        registro.put("carb", "1,89g");
        registro.put("cal", "8kcal");
        registro.put("azucares","0,87g" );
        registro.put("fibras","0,3g" );
        registro.put("grasas", "0,06g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1010);
        registro.put("proteina", "0,86g");
        registro.put("carb", "1,08g");
        registro.put("cal", "7kcal");
        registro.put("azucares","0,13g" );
        registro.put("fibras","0,7g" );
        registro.put("grasas", "0,12g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1011);
        registro.put("proteina", "8,85g");
        registro.put("carb", "49,42g");
        registro.put("cal", "266kcal");
        registro.put("azucares","5,67g" );
        registro.put("fibras","2,7g" );
        registro.put("grasas", "3,33g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1012);
        registro.put("proteina", "9,1g");
        registro.put("carb", "55,7g");
        registro.put("cal", "275kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","2,7g" );
        registro.put("grasas", "1,2g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1013);
        registro.put("proteina", "2,4g");
        registro.put("carb", "29,42g");
        registro.put("cal", "222kcal");
        registro.put("azucares","0,21g" );
        registro.put("fibras","2,7g" );
        registro.put("grasas", "10,46g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1014);
        registro.put("proteina", "13,3g");
        registro.put("carb", "70,4g");
        registro.put("cal", "361kcal");
        registro.put("azucares","1,3g" );
        registro.put("fibras","4,1g" );
        registro.put("grasas", "2,1g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1015);
        registro.put("proteina", "0,1g");
        registro.put("carb", "3,5g");
        registro.put("cal", "70kcal");
        registro.put("azucares","2,4g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "6,1g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1016);
        registro.put("proteina", "0g");
        registro.put("carb", "0g");
        registro.put("cal", "2kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "0g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1017);
        registro.put("proteina", "35,60g");
        registro.put("carb", "0,06g");
        registro.put("cal", "375kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "25,80g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1018);
        registro.put("proteina", "0g");
        registro.put("carb", "2g");
        registro.put("cal", "2kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "46g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1019);
        registro.put("proteina", "0g");
        registro.put("carb", "0g");
        registro.put("cal", "2kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "0g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1011);
        registro.put("proteina", "8,85g");
        registro.put("carb", "49,42g");
        registro.put("cal", "266kcal");
        registro.put("azucares","5,67g" );
        registro.put("fibras","2,7g" );
        registro.put("grasas", "3,33g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1020);
        registro.put("proteina", "12g");
        registro.put("carb", "0,08g");
        registro.put("cal", "70kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "0g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1021);
        registro.put("proteina", "1,1g");
        registro.put("carb", "28,1g");
        registro.put("cal", "109kcal");
        registro.put("azucares","25,7g" );
        registro.put("fibras","2,4g" );
        registro.put("grasas", "0g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1022);
        registro.put("proteina", "4,1g");
        registro.put("carb", "13,5g");
        registro.put("cal", "139kcal");
        registro.put("azucares","0g" );
        registro.put("fibras","0g" );
        registro.put("grasas", "8,8g");
        db.insert("info", null, registro);
        registro=new ContentValues();
        registro.put("idI", 1023);
        registro.put("proteina", "8g");
        registro.put("carb", "78g");
        registro.put("cal", "39kcal");
        registro.put("azucares","10g" );
        registro.put("fibras","1,5g" );
        registro.put("grasas", "5g");
        db.insert("info", null, registro);
    }

    /*
    *
    * Este método da de alta (inserta a las tablas) los alimentos marcados por el cliente.
    * Se dan de alta en las respectivas tablas
    * En este método se llama a la función "id" para generar el id del pedido y los alimentos*/

    public void alta(View v){
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        int idPedido, n, num;

        idPedido=id("numeroPedido", "pedido");
        ContentValues reg=new ContentValues();


        reg.put("numeroPedido",idPedido);
        reg.put("fechaEntrega", fecha.getText().toString());
        db.insert("pedido", null, reg);

        Toast.makeText(this, "Se ha dado de alta", Toast.LENGTH_LONG).show();

        reg=new ContentValues();



        if(carne.isChecked()){
            n=id("id", "proteina");
            reg.put("id", n);
            reg.put("nombreP", "carne");
            reg.put("idPedido", idPedido);
             reg.put("ref", 1001);
            db.insert("proteina", null, reg);
        }

        if(pollo.isChecked()){
            n=id("id", "proteina");
            reg.put("id", n);
            reg.put("nombreP", "pollo");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1002);
            db.insert("proteina", null, reg);
        }

        if(quesoPanela.isChecked()){
            n=id("id", "proteina");
            reg.put("id", n);
            reg.put("nombreP", "quesoPanela");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1003);
            db.insert("proteina", null, reg);
        }

        if(pescado.isChecked()){
            n=id("id", "proteina");
            reg.put("id", n);
            reg.put("nombreP", "pescado");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1004);
            db.insert("proteina", null, reg);
        }

        if(falafel.isChecked()){
            n=id("id", "proteina");
            reg.put("id", n);
            reg.put("nombreP", "falafel");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1005);
            db.insert("proteina", null, reg);
        }

        reg=new ContentValues();
        if(jicama.isChecked()){
            n=id("id", "verdura");
            reg.put("id", n);
            reg.put("nombreV", "jicama");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1006);
            db.insert("verdura", null, reg);
        }

        if(pepino.isChecked()){
            n=id("id", "verdura");
            reg.put("id", n);
            reg.put("nombreV", "pepino");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1007);
            db.insert("verdura", null, reg);
        }

        if(lechuga.isChecked()){
            n=id("id", "verdura");
            reg.put("id", n);
            reg.put("nombreV", "lechuga");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1008);
            db.insert("verdura", null, reg);
        }

        if(pimiento.isChecked()){
            n=id("id", "verdura");
            reg.put("id", n);
            reg.put("nombreV", "pimiento");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1009);
            db.insert("verdura", null, reg);
        }

        if(espinaca.isChecked()){
            n=id("id", "verdura");
            reg.put("id", n);
            reg.put("nombreV", "espinaca");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1010);
            db.insert("verdura", null, reg);
        }
        reg=new ContentValues();
        if(panArabe.isChecked()){
            n=id("id", "carbs");
            reg.put("id", n);
            reg.put("nombreC", "panArabe");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1011);
            db.insert("carbs", null, reg);
        }

        if(pure.isChecked()){
            n=id("id", "carbs");
            reg.put("id", n);
            reg.put("nombreC", "pure");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1012);
            db.insert("carbs", null, reg);
        }

        if(croutons.isChecked()){
            n=id("id", "carbs");
            reg.put("id", n);
            reg.put("nombreC", "croutons");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1013);
            db.insert("carbs", null, reg);
        }


        if(pasta.isChecked()){
            n=id("id", "carbs");
            reg.put("id", n);
            reg.put("nombreA", "pasta");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1014);
            db.insert("carbs", null, reg);
        }
        reg=new ContentValues();
        if(ad1.isChecked()){
            n=id("id", "aderezo");
            reg.put("id", n);
            reg.put("nombreA", "mostaza");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1015);
            db.insert("aderezo", null, reg);
        }

        if(ad2.isChecked()){
            n=id("id", "aderezo");
            reg.put("id", n);
            reg.put("nombreA", "limonCPim");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1016);
            db.insert("aderezo", null, reg);
        }

        if(ad3.isChecked()){
            n=id("id", "aderezo");
            reg.put("id", n);
            reg.put("nombreA", "quesoPar");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1017);
            db.insert("aderezo", null, reg);
        }

        if(ad4.isChecked()){
            n=id("id", "aderezo");
            reg.put("id", n);
            reg.put("nombreA", "chiles");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1018);
            db.insert("aderezo", null, reg);
        }

        if(ad5.isChecked()){
            n=id("id", "aderezo");
            reg.put("id", n);
            reg.put("nombreA", "salsaMex");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1019);
            db.insert("aderezo", null, reg);
        }
        reg=new ContentValues();
        if(eBar.isChecked()){
            n=id("id", "snack");
            reg.put("id", n);
            reg.put("nombreS", "energyBar");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1020);
            db.insert("snack", null, reg);
        }

        if(coctel.isChecked()){
            n=id("id", "snack");
            reg.put("id", n);
            reg.put("nombreS", "coctel");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1021);
            db.insert("snack", null, reg);
        }

        if(barraAma.isChecked()){
            n=id("id", "snack");
            reg.put("id", n);
            reg.put("nombreS", "amaranto");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1022);
            db.insert("snack", null, reg);
        }

        if(mix.isChecked()){
            n=id("id", "snack");
            reg.put("id", n);
            reg.put("nombreS", "nutMix");
            reg.put("idPedido", idPedido);
            reg.put("ref", 1023);
            db.insert("snack", null, reg);
        }
        db.close();


    }

    /*
    * Este método carga los elementos que contiene el pedido en un grid view */

   /* public void info(View v){
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        Cursor dr=db.rawQuery("select numeroPedido from pedido", null);
        int i=-1;
        String num;
        if(dr.moveToFirst()){
            i=dr.getInt(0);
            Toast.makeText(this, "pasa", Toast.LENGTH_LONG).show();
        }
        num=i+"";
        fecha.setText(num);

    }*/

   /*
   * Este método redirecciona la ventana Consulta*/

    public void redirect(View v){

        Intent intent=new Intent(this, Consulta.class);
        startActivity(intent);



    }

    /*
    * Este método es un método generico que genera un id con base a la tabla dada y el tipo de la id (genera un id para cualquier tabla)*/

    public int id(String tipo, String tabla){
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        Cursor dr=db.rawQuery("select max("+tipo+") from "+tabla+" ", null);
        int i;
        String num;


        if(dr.moveToFirst()){
            i=dr.getInt(0)+1;
        }else{
            if(tabla.equals("proteina") || tabla.equals("verdura") || tabla.equals("carbohidratos") || tabla.equals("snacks") || tabla.equals("aderezo")){
                i=400;
            }
            else
                i=1;
        }
        return i;

    }

}
