package com.example.administrador.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Consulta extends AppCompatActivity {

    private Spinner spinner;
    private GridView contenido;
    private int pos;
    private TextView comida;


/*
* Este método instancia la ventana
* También instancia el spinner y el grid view
*Los numeros de pedido se cargan al spinner desde aquí (al llamar "test()") para que al iniciar la ventana, ya estén cargados */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta);

        spinner= (Spinner) findViewById(R.id.spPedidos);
        contenido=(GridView) findViewById(R.id.gvData);
        comida=(TextView) findViewById(R.id.tvComida);
        test();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItemText = (String) parent.getItemAtPosition(position);
                pos=Integer.parseInt(selectedItemText);


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    /*
    * Este método jala los números de pedido y los inserta al spinner*/

    public void test(){
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        ArrayList<String> testAL=new ArrayList<String>();
        int i=0, n;
        String num;
        Cursor dr=db.rawQuery("select numeroPedido from pedido", null);
        while(dr.moveToNext()) {
            n = dr.getInt(i);
            num = n + "";
            testAL.add(num);

        }
        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, testAL);

        spinner.setAdapter(dataAdapter);

    }

    /*
    * Este método selecciona todos los elementos que hay en el pedido y los carga en un grid view*/
    public void data(int n){
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        Cursor dr=db.rawQuery("select fechaEntrega from pedido where pedido.numeroPedido="+n+"", null);
        ArrayList<String> content=new ArrayList<String>();
        int j=0;

        if(dr.moveToFirst()){
            content.add("Fecha de Entrega: "+dr.getString(j));
        }

        Cursor dr1=db.rawQuery("select nombreP from proteina, pedido where pedido.numeroPedido="+n+" and proteina.idPedido=pedido.numeroPedido", null);

        content.add("Proteinas:");
        while(dr1.moveToNext()){
            content.add(dr1.getString(j));

        }

        Cursor dr2=db.rawQuery("select nombreV from verdura, pedido where pedido.numeroPedido="+n+" and verdura.idPedido=pedido.numeroPedido", null);

        content.add("Verduras:");
        while(dr2.moveToNext()){
            content.add(dr2.getString(j));

        }

        Cursor dr3=db.rawQuery("select nombreC from carbs, pedido where pedido.numeroPedido="+n+" and carbs.idPedido=pedido.numeroPedido", null);

        content.add("Carbohidratos:");
        while(dr3.moveToNext()){
            content.add(dr3.getString(j));

        }

        Cursor dr4=db.rawQuery("select nombreA from aderezo, pedido where pedido.numeroPedido="+n+" and aderezo.idPedido=pedido.numeroPedido", null);

        content.add("Aderezo:");
        while(dr4.moveToNext()){
            content.add(dr4.getString(j));

        }

        Cursor dr6=db.rawQuery("select nombreS from snack, pedido where pedido.numeroPedido="+n+" and snack.idPedido=pedido.numeroPedido", null);

        content.add("Snack:");
        while(dr6.moveToNext()){
            content.add(dr6.getString(j));

        }
        ArrayAdapter<String> dataGAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, content);
        contenido.setAdapter(dataGAdapter);

    }


/*
* Al hacer click en el botón "Mostrar contenido", este método llama a la función "data()" la cual tiene como parámetro pos que es el numero de pedido*/

    public void loadData(View v){
        data(pos);
    }


    /*
    * Este método elimina el pedido ha sido seleccionado en el spinner*/
    public void eliminar(View v){
        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        try{
            db.delete("proteina", "id="+pos, null);
        }catch(Exception ex){

        }

        try{
            db.delete("verdura", "id="+pos, null);
        }catch(Exception ex){

        }

        try{
            db.delete("carbs", "id="+pos, null);
        }catch(Exception ex){

        }

        try{
            db.delete("aderezo", "id="+pos, null);
        }catch(Exception ex){

        }

        try{
            db.delete("snack", "id="+pos, null);
        }catch(Exception ex){

        }

        int ans=db.delete("pedido", "numeroPedido="+pos, null);

        if(ans==1){
            Toast.makeText(this, "Se ha dado de baja correctamente", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "Ha ocurrido un errror", Toast.LENGTH_LONG).show();
        }
    }




    /*
    * Los métodos "modificaRed" y "infoRed" redireccionan a las ventanas "Modificar" y "InfoNuri" respectivamente
    * Inserta un extra (en este caso un id) en el intent para que se pueda usar en la pagina siguente*/

    public void modificaRed(View v){
        Intent intent1=new Intent(this, Modificar.class);
        Bundle b=new Bundle();
        String pos1=""+pos;
        b.putString("session",pos1);
        intent1.putExtras(intent1);
        startActivity(intent1);
    }

    public void infoRed(View v){
        Intent intent2=new Intent(this, InfoNutri.class);
        Bundle b=new Bundle();
        String pos2=""+pos;
        b.putString("session",pos2);
        intent2.putExtras(intent2);
        startActivity(intent2);
    }

    /*
    * Este método redirecciona a una página web*/
    public void redirectWeb(View v){
        Intent intent2=new Intent(this, WebViewPag.class);
        Bundle b=new Bundle();
        String pos2=""+pos;
        b.putString("session",pos2);
        intent2.putExtras(intent2);
        startActivity(intent2);
    }



}
