package com.example.administrador.myapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import java.util.ArrayList;

public class InfoNutri extends AppCompatActivity {

    GridView gv;

    /*
    * Este método, aparte de instanciar la ventana, carga los datos de la información nutrimental de los productos contenidos en a ventana anterior
    * Usa un Bundle para recuperar el numero de pedido el cual es elegido en la ventana anterior*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_nutri);

        gv=(GridView) findViewById(R.id.gvDataInfo);

        AdminSQLiteOpenHelper admin=new AdminSQLiteOpenHelper(this, "administrador", null, 1);
        SQLiteDatabase db=admin.getWritableDatabase();
        ArrayList<String> content=new ArrayList<String>();

        Bundle bundle=this.getIntent().getExtras();//recupera lo que habia en la varible bundle de la clase anterior
        int n=bundle.getInt("idPedido");

        Cursor dr=db.rawQuery("select ref, nombreP from proteina, pedido where pedido.numeroPedido=n and pedido.numeroPedido=proteina.idPedido ", null);
        while(dr.moveToNext()){
            int clave=dr.getInt(0);
            content.add(dr.getString(1));
            Cursor dr1=db.rawQuery("select proteina , carb , cal , azucares , fibras , grasas from info where info.idI="+clave+"", null);
            if(dr1.moveToFirst()){
                content.add("Proteinas: "+dr1.getString(0));
                content.add("Carbohidratos: "+dr1.getString(1));
                content.add("Calorias: "+dr1.getString(2));
                content.add("Azucares: "+dr1.getString(3));
                content.add("Fibras: "+dr1.getString(4));
                content.add("Grasas: "+dr1.getString(5));
           }



        }

        Cursor drV=db.rawQuery("select ref, nombreV from verdura, pedido where pedido.numeroPedido=n and pedido.numeroPedido=verdura.idPedido ", null);
        while(drV.moveToNext()){
            int claveV=drV.getInt(0);
            content.add(dr.getString(1));
            Cursor dr2=db.rawQuery("select proteina , carb , cal , azucares , fibras , grasas from info where info.idI="+claveV+"", null);
            if(dr2.moveToFirst()){
                content.add("Proteinas: "+dr2.getString(0));
                content.add("Carbohidratos: "+dr2.getString(1));
                content.add("Calorias: "+dr2.getString(2));
                content.add("Azucares: "+dr2.getString(3));
                content.add("Fibras: "+dr2.getString(4));
                content.add("Grasas: "+dr2.getString(5));
            }



        }
        ArrayAdapter<String> dataGAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, content);
        gv.setAdapter(dataGAdapter);

        Cursor drC=db.rawQuery("select ref, nombreC from carbs, pedido where pedido.numeroPedido=n and pedido.numeroPedido=carbs.idPedido ", null);
        while(dr.moveToNext()){
            int claveC=drC.getInt(0);
            content.add(drC.getString(1));
            Cursor dr3=db.rawQuery("select proteina , carb , cal , azucares , fibras , grasas from info where info.idI="+claveC+"", null);
            if(dr3.moveToFirst()){
                content.add("Proteinas: "+dr3.getString(0));
                content.add("Carbohidratos: "+dr3.getString(1));
                content.add("Calorias: "+dr3.getString(2));
                content.add("Azucares: "+dr3.getString(3));
                content.add("Fibras: "+dr3.getString(4));
                content.add("Grasas: "+dr3.getString(5));
            }



        }

        Cursor drA=db.rawQuery("select ref, nombreA from aderezo, pedido where pedido.numeroPedido=n and pedido.numeroPedido=aderezo.idPedido ", null);
        while(dr.moveToNext()){
            int claveA=drA.getInt(0);
            content.add(drA.getString(1));
            Cursor dr4=db.rawQuery("select proteina , carb , cal , azucares , fibras , grasas from info where info.idI="+claveA+"", null);
            if(dr4.moveToFirst()){
                content.add("Proteinas: "+dr4.getString(0));
                content.add("Carbohidratos: "+dr4.getString(1));
                content.add("Calorias: "+dr4.getString(2));
                content.add("Azucares: "+dr4.getString(3));
                content.add("Fibras: "+dr4.getString(4));
                content.add("Grasas: "+dr4.getString(5));
            }


            Cursor drS=db.rawQuery("select ref, nombreS from snack, pedido where pedido.numeroPedido=n and pedido.numeroPedido=snack.idPedido ", null);
            while(drS.moveToNext()){
                int claveS=drS.getInt(0);
                content.add(drS.getString(1));
                Cursor dr5=db.rawQuery("select proteina , carb , cal , azucares , fibras , grasas from info where info.idI="+claveS+"", null);
                if(dr5.moveToFirst()){
                    content.add("Proteinas: "+dr5.getString(0));
                    content.add("Carbohidratos: "+dr5.getString(1));
                    content.add("Calorias: "+dr5.getString(2));
                    content.add("Azucares: "+dr5.getString(3));
                    content.add("Fibras: "+dr5.getString(4));
                    content.add("Grasas: "+dr5.getString(5));
                }



            }

        }
    }


}
