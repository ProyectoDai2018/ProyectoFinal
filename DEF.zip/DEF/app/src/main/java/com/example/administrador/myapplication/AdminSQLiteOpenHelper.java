package com.example.administrador.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AdminSQLiteOpenHelper extends SQLiteOpenHelper {

    public AdminSQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    /*Crea las tablas que se van a usar en el proyecto*/

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table pedido (numeroPedido integer primary key, fechaEntrega text)");
        db.execSQL("create table proteina (id integer primary key, nombreP text, idPedido integer references pedido, ref integer references info)");
        db.execSQL("create table verdura(id integer primary key, nombreV text, idPedido integer references pedido, ref integer references info)");
        db.execSQL("create table carbs(id integer primary key, nombreC text, idPedido integer references pedido, ref integer references info)");
        db.execSQL("create table aderezo(id integer primary key, nombreA text, idPedido integer references pedido, ref integer references info)");
        db.execSQL("create table snack(id integer primary key, nombreS text, idPedido integer references pedido, ref integer references info)");
        db.execSQL("create table info (idI integer primary key, proteina text, carb text, cal integer, azucares text, fibras text, grasas text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists pedido");
        //db.execSQL("create table pedido (id, integer primary key, numeroPedido integer, proteina text, verdura text, carbohidrato text, aderezo text, snack text)");
        //db.execSQL("create table pedido (numeroPedido integer primary key, fechaEntrega text)");

        db.execSQL("drop table if exists proteina");
        //db.execSQL("create table proteina (id integer primary key, nombreP text, idPedido integer references pedido)");

        db.execSQL("drop table if exists verdura");
        //db.execSQL("create table verdura (id integer primary key, nombreV text, idPedido integer references pedido)");

        db.execSQL("drop table if exists carbs");
        //db.execSQL("create table carbs(id integer primary key, nombreC text, idPedido integer references pedido)");

        db.execSQL("drop table if exists aderezo");
        //db.execSQL("create table aderezo(id integer primary key, nombreA text, idPedido integer references pedido)");

        db.execSQL("drop table if exists snack");
        //db.execSQL("create table snack(id integer primary key, nombreA text, idPedido integer references pedido)");

        db.execSQL("drop table if exists info");
        db.execSQL("create table info (idI integer primary key, proteina text, carb text, cal integer, azucares text, fibras text, grasas text)");


    }


}
