package com.example.administrador.myapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Modificar extends AppCompatActivity {
    private EditText fechaNtxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);
        fechaNtxt=(EditText) findViewById(R.id.fechaTxt);



    }


    /*Este método modifica la fecha del pedido a la fecha nueva que ingresa el cliente*/

   public void modificarFechaPedido(View v) {
       Bundle bd=this.getIntent().getExtras();
      int clave= Integer.parseInt(bd.get("session").toString());


       AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administrador", null, 1);
       SQLiteDatabase db = admin.getWritableDatabase();

       ContentValues registro = new ContentValues();//es una lista de valores que guarda el nombre de la columna y el valor
       registro.put("fechaEntrega", fechaNtxt.getText().toString());
       int cant=db.update("pedido", registro, "numeroPedido="+clave, null);
       db.close();
       Toast.makeText(this, "Se ha modificado correctamente", Toast.LENGTH_LONG).show();

   }

}
